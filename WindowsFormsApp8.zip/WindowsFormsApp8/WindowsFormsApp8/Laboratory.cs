﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace WindowsFormsApp8
{
    public partial class Laboratory : Form
    {
        const float DgXd = float.MinValue;
        const float GgXg = float.MaxValue;

        float[,] TWS;

        public Laboratory()
        {
            InitializeComponent();

            dgvTWS.Visible = false;
            chtWykresSzeregu.Visible = false;
        }

        private void Laboratory_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            StartWindow form1 = new StartWindow();
            form1.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnObliczSumeSzeregu_Click(object sender, EventArgs e)
        {
            errorProvider1.Dispose();
            float X, Eps;
            if (!PobranieDanychWejściowych_X_Eps(out X, out Eps))
                return;

            float Suma;
            ushort LicznikWyrazów;
            //MessageBox.Show("Jestem przed wywołaniem metody ObliczWartośćSzeregu");
            Suma = ObliczWartośćSzeregu(X, Eps, out LicznikWyrazów);
            //MessageBox.Show("Jestem po wywołaniem metody ObliczWartośćSzeregu");
            txtSuma.Text = Suma.ToString();
            txtLicznikWyrazuSzeregu.Text = LicznikWyrazów.ToString();
            txtX.Enabled = false;
        }

        bool PobranieDanychWejściowych_X_Eps(out float X, out float Eps)
        {
            X = Eps = 0.0F;
            if (!float.TryParse(txtX.Text, out X))
            {
                errorProvider1.SetError(txtX, "ERROR: w zapisie wartości zmiennej X wystąpil niedozwolony znak");
                return false;
            }

            if (!float.TryParse(txtEps.Text, out Eps))
            {
                errorProvider1.SetError(txtEps, "ERROR: w zapisie dokłsdności zmiennej Eps wystąpil niedozwolony znak");
                return false;
            }

            if ((Eps <= 0.0F) || (Eps >= 1.0F))
            {
                errorProvider1.SetError(txtEps, "ERROR: podana dokłsdności zmiennej Eps spełnia warunku wejściowego: 0.0 < Eps < 1.0");
                return false;
            }

            return true;
        }

        float ObliczWartośćSzeregu(float X, float Eps, out ushort NumerWyrazu)
        {
            NumerWyrazu = 0;
            float Suma = 0.0F;
            float w = 1.0F;
            do
            {
                Suma = Suma + w;
                NumerWyrazu++;
                w = w * (-1) * X / NumerWyrazu;
            }

            while (Math.Abs(w) > Eps);
            return Suma;
        }

        private void btnResetuj_Click(object sender, EventArgs e)
        {
            this.Hide();
            Laboratory form2 = new Laboratory();
            form2.Show();
        }

        private void btnWizualizacjaTabelaryczna_Click(object sender, EventArgs e)
        {
            errorProvider1.Dispose();
            float Eps, Xd, Xg, h;
            if(!PobranieDanychWejściowych_Eps_Xd_Xg_h(out Xd, out Xg, out h, out Eps))
            {
                return;
            }

            //float[,] TWS;

            if (TWS is null)
            {
                TablicowanieWartościSzeregu(Xd, Xg, h, Eps, out TWS);
            }

            WpisanieDoKontrolkiDataGridViewTablicy(TWS, dgvTWS);

            dgvTWS.Visible = true;
            chtWykresSzeregu.Visible = false;
        }

        #region Deklaracje metod pomocniczch

        bool PobranieDanychWejściowych_Eps_Xd_Xg_h(out float Xd, out float Xg, out float h, out float Eps)
        {
            Xd = Xg = h = Eps = 0.0F;
            if (!float.TryParse(txtXd.Text, out Xd))
            {
                errorProvider1.SetError(txtXd, "ERROR: wystąpił niedozwolony znak w zapisie danej Xd");
                return false;
            }

            if ((Xd < DgXd) || (Xd > GgXg))
            {
                errorProvider1.SetError(txtXd, "ERROR: podana wartość Xd nie należy do przedziału zbiezności szeregu");
                return false;
            }

            if (!float.TryParse(txtXg.Text, out Xg))
            {
                errorProvider1.SetError(txtXg, "ERROR: wystąpił niedozwolony znak w zapisie danej Xg");
                return false;
            }

            if ((Xg < DgXd) || (Xg > GgXg))
            {
                errorProvider1.SetError(txtXg, "ERROR: podana wartość Xg nie należy do przedziału zbiezności szeregu");
                return false;
            }

            if (Xg < Xd)
            {
                errorProvider1.SetError(txtXg, "ERROR: podana wartość Xg nie może być mniejsza od podaniej wartoszći Xd");
                return false;
            }

            txtXg.Enabled = false;
            txtXd.Enabled = false;

            if (!float.TryParse(txtH.Text, out h))
            {
                errorProvider1.SetError(txtH, "ERROR: w zapisie przyrostu 'h' wystąpił niedozwolony znak");
                return false;
            }

            if (h >= (Xg - Xd))
            {
                errorProvider1.SetError(txtH, "ERROR: wartość przyrostu 'h' nie może być większa od szerekości przedziału: (Xg - Xd)");
                return false;
            }

            txtH.Enabled = false;

            if (!float.TryParse(txtEps.Text, out Eps))
            {
                errorProvider1.SetError(txtEps, "ERROR: w zapisie dokładności obliczeń Eps wystąpił niedozwolony znak");
                return false;
            }

            if ((Eps <= 0.0F) || (Eps >= 1.0F))
            {
                errorProvider1.SetError(txtEps, "ERROR: podana wartość dokładbości obliczeń Eps nie spiłnia warunku wejściowego: 0.0 < Eps < 1.0");
                return false;
            }

            txtEps.Enabled = false;

            return true;
        }

        void TablicowanieWartościSzeregu(float Xd, float Xg, float h, float Eps, out float[,] TWS)
        {
            int n = (int)((Xg - Xd) / h + 1);
            TWS = new float[n + 1, 3];
            float X;
            int i;
            ushort LicznikZsumowanychWyrazów;
            
            for(X = Xd, i = 0; i < TWS.GetLength(0); i++, X = Xd + i * h) 
            {
                TWS[i, 0] = X;
                TWS[i, 1] = ObliczWartośćSzeregu(X, Eps, out LicznikZsumowanychWyrazów);
                TWS[i, 2] = LicznikZsumowanychWyrazów;
            }
        }

        void WpisanieDoKontrolkiDataGridViewTablicy(float[,] TWS, DataGridView dgvTWS)
        {
            dgvTWS.Rows.Clear();

            for (int i = 0; i < TWS.GetLength(0); i++)
            {
                dgvTWS.Rows.Add();
                dgvTWS.Rows[i].Cells[0].Value = string.Format("{0:0.00}", TWS[i, 0]);
                dgvTWS.Rows[i].Cells[1].Value = string.Format("{0:0.000}", TWS[i, 1]);
                dgvTWS.Rows[i].Cells[2].Value = string.Format("{0}", (int)TWS[i, 2]);
            }
        }

        #endregion

        private void restartProgramyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void kolorTłaWykresuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog PaletaKolorów = new ColorDialog();
            PaletaKolorów.Color = this.BackColor;
            if (PaletaKolorów.ShowDialog() == DialogResult.OK)
            {
                this.BackColor = PaletaKolorów.Color;
            }

            PaletaKolorów.Dispose();
        }

        private void kolorLiniiWykresuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog PaletaKolorów = new ColorDialog();
            PaletaKolorów.Color = this.ForeColor;
            if (PaletaKolorów.ShowDialog() == DialogResult.OK)
            {
                this.ForeColor = PaletaKolorów.Color;
            }

            PaletaKolorów.Dispose();
        }

        private void czcionkaToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FontDialog OknoCzcionki = new FontDialog();
            OknoCzcionki.Font = this.Font;
            if (OknoCzcionki.ShowDialog() == DialogResult.OK)
            {
                this.Font = OknoCzcionki.Font;
            }

            OknoCzcionki.Dispose();
        }

        private void zapisanieTablicyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (TWS is null)
            {
                float Xd, Xg, h, Eps;

                if (!PobranieDanychWejściowych_Eps_Xd_Xg_h(out Xd, out Xg, out h, out Eps))
                {
                    MessageBox.Show("UWAGA: wystąpil bład w zapisie danych wejściowych i dane polecenie z menu 'Plik' nie może być obslużone");
                    return;
                }

                TablicowanieWartościSzeregu(Xd, Xg, h, Eps, out TWS);
            }

            SaveFileDialog OknoWyboruPlikuDoZapisu = new SaveFileDialog();
            OknoWyboruPlikuDoZapisu.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            OknoWyboruPlikuDoZapisu.FilterIndex = 1;
            OknoWyboruPlikuDoZapisu.RestoreDirectory = true;
            OknoWyboruPlikuDoZapisu.InitialDirectory = "C:\\";
            OknoWyboruPlikuDoZapisu.Title = "Wybór pliku do zapisu TWS (Tabloca Watrości Seregu)";

            if (OknoWyboruPlikuDoZapisu.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamWriter PlikZnakowy = new System.IO.StreamWriter(OknoWyboruPlikuDoZapisu.FileName);
                try
                {
                    int i;
                    for (i = 0; i < TWS.GetLength(0); i++)
                    {
                        PlikZnakowy.Write(TWS[i, 0].ToString());
                        PlikZnakowy.Write("; \t");
                        PlikZnakowy.Write(TWS[i, 1].ToString());
                        PlikZnakowy.Write("; \t");
                        PlikZnakowy.WriteLine(TWS[i, 2].ToString());
                    }
                }

                catch(Exception ex)
                {
                    MessageBox.Show("ERROR: wystąpil błąd podczas zapisu danuch z TWS do pliku");
                }

                finally
                {
                    PlikZnakowy.Close();
                }
            }

            else
            {
                MessageBox.Show("UWAGA: nie został wybrany pliku do wpisania danych z tablicy TWS, to dane polecenie z menu 'Plik' nie może być wykonane");
            }
        }

        private void odczytanieTablicyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog OknoWyboryPlikuDoOdczytu = new OpenFileDialog();
            OknoWyboryPlikuDoOdczytu.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            OknoWyboryPlikuDoOdczytu.FilterIndex = 1;
            OknoWyboryPlikuDoOdczytu.RestoreDirectory = true;
            OknoWyboryPlikuDoOdczytu.InitialDirectory = "C:\\";
            OknoWyboryPlikuDoOdczytu.Title = "Wybór pliku do odcztu i zapisu TWS (Tabloca Watrości Seregu)";

            if (OknoWyboryPlikuDoOdczytu.ShowDialog() == DialogResult.OK)
            {
                System.IO.StreamReader PlikZnakowy = new System.IO.StreamReader(OknoWyboryPlikuDoOdczytu.FileName);
                string WierszDanych;
                ushort LicznikWierszy = 0;
                while ((WierszDanych = PlikZnakowy.ReadLine()) != null)
                {
                    LicznikWierszy++;
                }

                PlikZnakowy.Close();
                TWS = new float[LicznikWierszy, 3];
                PlikZnakowy = new System.IO.StreamReader(OknoWyboryPlikuDoOdczytu.FileName);
            }

            else
            {
                MessageBox.Show("UWAGA: nie został wybrany żaden plik do odczytu i wybrane polecenie z menu 'Plik' nie będzie wykonany");
            }
        }

        private void btnWizualizacjaGraficzna_Click(object sender, EventArgs e)
        {
            errorProvider1.Dispose();
            float Xd, Xg, h, Eps;
            if (!PobranieDanychWejściowych_Eps_Xd_Xg_h(out Xd, out Xg, out  h, out Eps))
            {
                return;
            }

            if (TWS is null)
            {
                TablicowanieWartościSzeregu(Xd, Xg, h, Eps, out TWS);
            }

            WpisanieWynikówDoKontrolkiChart(TWS, chtWykresSzeregu);

            dgvTWS.Visible = false;
            chtWykresSzeregu.Visible = true;
        }

        void WpisanieWynikówDoKontrolkiChart(float[,] TWS, Chart chtWykresSzeregu)
        {
            chtWykresSzeregu.BorderlineWidth = 1;
            chtWykresSzeregu.BorderlineColor = Color.Black;
            chtWykresSzeregu.BorderlineDashStyle = ChartDashStyle.Solid;
            chtWykresSzeregu.Titles.Add("Wykres zmian wartości szeregu S(X)");
            chtWykresSzeregu.Legends.FindByName("Legend1").Docking = Docking.Bottom;
            chtWykresSzeregu.BackColor = Color.White;
            chtWykresSzeregu.ChartAreas[0].AxisX.Title = "Wartości X";
            chtWykresSzeregu.ChartAreas[0].AxisY.Title = "Wartości S(X)";
            chtWykresSzeregu.ChartAreas[0].AxisX.LabelStyle.Format = "{0:f2}";
            chtWykresSzeregu.ChartAreas[0].AxisY.LabelStyle.Format = "{0:f2}";
            chtWykresSzeregu.Series.Clear();
            chtWykresSzeregu.Series.Add("Seria 0");
            chtWykresSzeregu.Series[0].XValueMember = "X";
            chtWykresSzeregu.Series[0].YValueMembers = "Y";
            chtWykresSzeregu.Series[0].IsVisibleInLegend = true;
            chtWykresSzeregu.Series[0].Name = "Wartość szeregu potęgowego S(X)";
            chtWykresSzeregu.Series[0].ChartType = SeriesChartType.Line;
            chtWykresSzeregu.Series[0].Color = Color.Black;
            chtWykresSzeregu.Series[0].BorderDashStyle = ChartDashStyle.Solid;
            chtWykresSzeregu.Series[0].BorderWidth = 1;

            for (int i = 0; i < TWS.GetLength(0); i++)
            {
                chtWykresSzeregu.Series[0].Points.AddXY(TWS[i, 0], TWS[i, 1]);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}